import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { ITodo } from '@app/todos/interfaces';
import { TodosService } from '@app/todos/services/todos.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as todoSelectors from '../../state/todo.selectors';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-todos-list',
  styleUrls: ['./todo-list.component.scss'],
  templateUrl: './todo-list.component.html'
})
export class TodosListComponent implements OnInit, OnDestroy {
  todoList: ITodo[];
  subscription$ = new Subject<void>();
  todoListForCount: ITodo[];
  filtertext = 'all';
  todoLeftCount: number;
  todoForm: FormGroup;

  constructor(
    private store: Store<any>,
    private todosService: TodosService,
    private formBuilder: FormBuilder
  ) {}
  ngOnInit() {
    this.todoForm = this.formBuilder.group({
      todo: ['', Validators.required]
    });
    this.loadTodos();
  }

  removeTodo(id: number): void {
    this.todosService.removeTodo(id);
  }

  editTodo(id: number): void {
    this.todosService.editTodo(id, true);
  }

  updateTodo(id: number, text: string): void {
    this.todosService.updateTodo(id, text);
  }

  todoToggle(id, completed): void {
    this.todosService.toggleComplete(id, !completed);
    this.getToDoCount();
  }

  getToDoCount(): void {
    this.todoLeftCount = this.todoListForCount.filter(
      todo => todo.completed === false
    ).length;
  }

  addTodo(): void {
    if (this.todoForm.get('todo').valid) {
      const todoItem: ITodo = {
        text: this.todoForm.get('todo').value,
        completed: false,
        id: this.todoListForCount.length + 1,
        editing: false
      };
      this.todosService.addTodo(todoItem);
      this.todoForm.reset();
    }
  }
  loadTodos() {
    this.store.select(todoSelectors.allTodos).pipe(takeUntil(this.subscription$)).subscribe((todos: ITodo[]) => {
      this.todoList = todos;
      this.todoListForCount = todos;
      this.getToDoCount();
    });
  }

  filterTodo(filtertext: string): void {
    this.filtertext = filtertext;
    this.store.select(todoSelectors.allTodos).pipe(takeUntil(this.subscription$)).subscribe((todos: ITodo[]) => {
      if (this.filtertext === 'active') {
        this.todoList = todos.filter(ele => ele.completed === false);
      } else if (this.filtertext === 'completed') {
        this.todoList = todos.filter(ele => ele.completed === true);
      } else {
        this.todoList = todos;
      }
      this.getToDoCount();
    });
  }

  clearComplete(): void {
    this.todosService.clearCompleted();
  }

  cancelEditingTodo(id: number): void {
    this.loadTodos();
    this.todosService.editTodo(id, false);
  }
  ngOnDestroy(): void {
    this.subscription$.next();
    this.subscription$.complete();
  }
}
