export interface ITodo {
  text?: string;
  completed?: boolean;
  id?: number;
  editing?: boolean;
}
