import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { ITodo } from '../interfaces';
import { ITodosState } from '../state/todos.reducer';
import * as TodoActions from '../state/todo.actions';
import * as todoSelectors from '../state/todo.selectors';

@Injectable()
export class TodosService {
  allTodos$: Observable<ITodo[]>;

  constructor(private store: Store<ITodosState>) {
    this.allTodos$ = this.store.select(todoSelectors.allTodos);
  }

  addTodo(todo: ITodo): void {
    this.store.dispatch(new TodoActions.AddTodo(todo));
  }

  removeTodo(id: number): void {
    this.store.dispatch(new TodoActions.RemoveTodo(id));
  }

  toggleComplete(id: number, completed: boolean): void {
    this.store.dispatch(new TodoActions.ToggleCompleted(id, completed));
  }

  toggleAllCompleted(toggle: boolean): void {
    this.store.dispatch(new TodoActions.ToggleAllCompleted(toggle));
  }

  updateTodo(id: number, text: string): void {
    this.store.dispatch(new TodoActions.UpdateTodo(id, text));
  }

  editTodo(id: number, editing: boolean): void {
    this.store.dispatch(new TodoActions.EditTodo(id, editing));
  }

  clearCompleted(): void {
    this.store.dispatch(new TodoActions.ClearCompleted());
  }
}
