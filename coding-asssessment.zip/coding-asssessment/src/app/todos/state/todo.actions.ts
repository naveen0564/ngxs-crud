import {  Action } from '@ngrx/store';
import { ITodo } from '../interfaces';
export const TODO_ADD = '[Todos] Add Todo';
export const TODO_REMOVE = '[Todos] Remove Todo';
export const TODO_UPDATE = '[Todos] Update Todo';
export const TODO_COMPLETE = 'Todos] Toggle Completed';
export const TOGGLE_ALL_COMPLETED = '[Todos] Toggle All Completed';
export const TODO_EDIT = '[Todos] Edit Todo';
export const TODO_CLEARCOMPLETE = '[Todos] Clear Completed';

export class AddTodo implements Action {
  readonly type = TODO_ADD;
  constructor(public todo: ITodo) {}
}

export class RemoveTodo implements Action {
  readonly type = TODO_REMOVE;
  constructor(public id: number ) {}
}

export class UpdateTodo implements Action {
  readonly type = TODO_UPDATE;
  constructor(public id: number, public text: string ) {}
}

export class ToggleCompleted implements Action {
  readonly type = TODO_COMPLETE;
  constructor(public id: number, public completed: boolean ) {}
}

export class ToggleAllCompleted implements Action {
  readonly type = TOGGLE_ALL_COMPLETED;
  constructor(public toggle: boolean) {}
}

export class EditTodo implements Action {
  readonly type = TODO_EDIT;
  constructor(public id: number, public editing: boolean) {}
}

export class ClearCompleted implements Action {
  readonly type = TODO_CLEARCOMPLETE;
  constructor() {}
}

export type TodoActionTypes = | AddTodo | RemoveTodo | UpdateTodo | ToggleCompleted | ToggleAllCompleted | EditTodo | ClearCompleted;
