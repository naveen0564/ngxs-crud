import * as TodoActions from './todo.actions';
import { FILTER_MODES } from './../constants/filter-modes';
import { ITodo } from '../interfaces/ITodo';

export interface ITodosState {
  filterMode?: FILTER_MODES;
  todos?: ITodo[];
}

export const initialState: ITodosState = {
  filterMode: 'All',
  todos: []
};

export function todosReducer(
  state: ITodosState = initialState,
  action: TodoActions.TodoActionTypes
) {
  switch (action.type) {
    case TodoActions.TODO_ADD: {
      const todos = [action.todo, ...state.todos];
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TODO_REMOVE: {
      const todos = [...state.todos].filter(todo => todo.id !== action.id);
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TODO_UPDATE: {
      const todos = state.todos.map(todo => {
        if (todo.id === action.id) {
          const todoItem = {
            text: action.text,
            completed: todo.completed,
            id: action.id,
            editing: false
          };
          return todoItem;
        } else {
          return todo;
        }
      });
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TODO_COMPLETE: {
      const todos = state.todos.map(todo => {
        if (todo.id === action.id) {
          const todoItem = {
            text: todo.text,
            completed: action.completed,
            id: action.id,
            editing: todo.editing
          };
          return todoItem;
        } else {
          return todo;
        }
      });
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TOGGLE_ALL_COMPLETED: {
      const todos = state.todos.map(todo => {
        const todoItem = {
          text: todo.text,
          completed: action.toggle,
          id: todo.id,
          editing: todo.editing
        };
        return todoItem;
      });
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TOGGLE_ALL_COMPLETED: {
      const todos = state.todos.map(todo => {
        const todoItem = {
          text: todo.text,
          completed: action.toggle,
          id: todo.id,
          editing: todo.editing
        };
        return todoItem;
      });
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TODO_EDIT: {
      const todos = state.todos.map(todo => {
        if (todo.id === action.id) {
          const todoItem = {
            text: todo.text,
            completed: todo.completed,
            id: action.id,
            editing: action.editing
          };
          return todoItem;
        } else {
          return todo;
        }
      });
      return {
        ...state,
        todos
      };
    }
    case TodoActions.TODO_CLEARCOMPLETE: {
      const todos = state.todos.filter(todo => todo.completed === false);
      return {
        ...state,
        todos
      };
    }
    default:
      return state;
  }
}

export const filterMode = (state: ITodosState) => state.filterMode;
export const todos = (state: ITodosState) => state.todos;
